### Hexlet tests and linter status:
[![Actions Status](https://github.com/time9v/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/time9v/python-project-49/actions)


### Maintainability Badge:
<a href="https://codeclimate.com/github/time9v/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7faa86dd57a58302ab40/maintainability" /></a>

